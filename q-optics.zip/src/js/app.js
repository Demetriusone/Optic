import 'dom4';
import 'babel-polyfill';
import 'svgxuse';
import './Common';
